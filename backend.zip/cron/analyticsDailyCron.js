import Payment from '../models/Payment.js';

export const recomputeDailyMetrics = async () => {
  // extend with aggregation to precompute analytics
  console.log('analyticsDailyCron: recompute metrics');
};
